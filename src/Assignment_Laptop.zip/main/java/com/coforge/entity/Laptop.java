package com.coforge.entity;

public class Laptop {
	int serial_no;
	String graphic_card,ram,company;
	public int getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(int serial_no) {
		this.serial_no = serial_no;
	}
	public String getGraphic_card() {
		return graphic_card;
	}
	public void setGraphic_card(String graphic_card) {
		this.graphic_card = graphic_card;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	


}
